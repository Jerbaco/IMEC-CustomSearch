declare interface IImecRedirectUsersApplicationCustomizerStrings {
  Title: string;
}

declare module 'ImecRedirectUsersApplicationCustomizerStrings' {
  const strings: IImecRedirectUsersApplicationCustomizerStrings;
  export = strings;
}
