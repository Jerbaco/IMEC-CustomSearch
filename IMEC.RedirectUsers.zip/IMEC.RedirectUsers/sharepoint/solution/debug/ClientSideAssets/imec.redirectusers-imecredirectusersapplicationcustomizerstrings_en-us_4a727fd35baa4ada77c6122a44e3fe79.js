define([], function() {
  return {
    "Title": "ImecRedirectUsersApplicationCustomizer"
  }
});